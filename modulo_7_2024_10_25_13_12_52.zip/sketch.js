let palavra //criando a variável "palavra"

function setup() { //função "setup"
  createCanvas(400, 400); //criando o cenário
  
  palavra = palavraAleatoria() //criando a função "palavra"
  
}

  function palavraAleatoria() { //função "palavraAleatoria"
  let palavras = ["Cachorro", "Gato", "Pássaro"]; //criando as palavras
  return random(palavras); //retornando a variável "palavra" e "sorteando" as palavras
}

function inicializaCores() {
  background("white"); //cor do fundo
  fill("black"); //cor das letras
  textSize(60); //tamanho do texto
  textAlign(CENTER, CENTER); //função para alinhar o texto no centro
} //criando a função "inicializaCores"

function draw() {
  inicializaCores()

  let maximo = width; //variável "maximo"
  let minimo = 0; //variável "minimo"

  let quantidade = map(mouseX, 0, width, 1, palavra.length); //quantidade de letras que serão utilizadas, sempre vai iniciar com o "A"
  let parcial = palavra.substring(0, quantidade); //separando as letras
  text(parcial, 200, 200); //posição do texto
    
  }
  
  